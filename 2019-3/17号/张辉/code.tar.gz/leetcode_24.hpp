//
// Created by pip on 19-3-10.
//
#include <bits/stdc++.h>

using namespace std;

class Solution {
public:


};

void test() {
	Solution s;
	cout << "hello world" << endl;
}